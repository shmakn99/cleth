# Example Package

This is a package to verify and predict essentiality of proteins from the corresponding Protein Protein Interaction data.
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.